﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace MathClasses
{
    /* Write Matrix data types for 3D matrices, including homogeneous 4D matrices. Types implement methods for:
     * 1: multiplication
     * 2: vectors transformation
     * 3: transpose
     * 4: setting up as rotation matrices
    */

    public struct Matrix4
    // 5.1.0.0      struct
    {
        // 5.1.0.1 - 5.1.0.12:   automatically-initialised default variables
        public float m00, m01, m02, m03;
        public float m10, m11, m12, m13;
        public float m20, m21, m22, m23;
        public float m30, m31, m32, m33;

        // 5.1.1.0      overloaded constructor ROW MAJOR ORDER (replace default xyzw with passed-in xyzw)
        public Matrix4(float _m00, float _m01, float _m02, float _m03, float _m10, float _m11, float _m12, float _m13, float _m20, float _m21, float _m22, float _m23, float _m30, float _m31, float _m32, float _m33)


        // 5.1.1.0      overloaded constructor COLUMN MAJOR ORDER (replace default xyzw with passed-in xyzw)
        // public Matrix4(float _m00, float _m10, float _m20, float _m30, float _m01, float _m11, float _m21, float _m31, float _m02, float _m12, float _m22, float _m32, float _m03, float _m13, float _m23, float _m33)
        {
            // 5.1.1.1 - 5.1.1.12   ROW MAJOR ORDER
            // row 1
            m00 = _m00; // (Vector A x-axis value to be passed to the constructor, overwrites the default)
            m01 = _m01; // (Vector A y-axis value to be passed to the constructor, overwrites the default)
            m02 = _m02; // (Vector A z-axis value to be passed to the constructor, overwrites the default)
            m03 = _m03; // (Vector A w-axis value to be passed to the constructor, overwrites the default)

            // row 2
            m10 = _m10; // (Vector B x-axis value to be passed to the constructor, overwrites the default)
            m11 = _m11; // (Vector B y-axis value to be passed to the constructor, overwrites the default)
            m12 = _m12; // (Vector B z-axis value to be passed to the constructor, overwrites the default)
            m13 = _m13; // (Vector B w-axis value to be passed to the constructor, overwrites the default)

            // row 3
            m20 = _m20; // (Vector C x-axis value to be passed to the constructor, overwrites the default)
            m21 = _m21; // (Vector C y-axis value to be passed to the constructor, overwrites the default)
            m22 = _m22; // (Vector C z-axis value to be passed to the constructor, overwrites the default)
            m23 = _m23; // (Vector C w-axis value to be passed to the constructor, overwrites the default)

            // row 4
            m30 = _m30; // (Vector D x-axis value to be passed to the constructor, overwrites the default)
            m31 = _m31; // (Vector D y-axis value to be passed to the constructor, overwrites the default)
            m32 = _m32; // (Vector D z-axis value to be passed to the constructor, overwrites the default)
            m33 = _m33; // (Vector D w-axis value to be passed to the constructor, overwrites the default)

            /*
            // 5.1.1.1 - 5.1.1.12   COLUMN MAJOR ORDER
            // row 1
            m00 = _m00; // (Vector A x-axis value to be passed to the constructor, overwrites the default)
            m01 = _m01; // (Vector B x-axis value to be passed to the constructor, overwrites the default)
            m02 = _m02; // (Vector C x-axis value to be passed to the constructor, overwrites the default)
            m03 = _m03; // (Vector D x-axis value to be passed to the constructor, overwrites the default)

            // row 2
            m10 = _m10; // (Vector A y-axis value to be passed to the constructor, overwrites the default)
            m11 = _m11; // (Vector B y-axis value to be passed to the constructor, overwrites the default)
            m12 = _m12; // (Vector C y-axis value to be passed to the constructor, overwrites the default)
            m13 = _m13; // (Vector D y-axis value to be passed to the constructor, overwrites the default)

            // row 3
            m20 = _m20; // (Vector A z-axis value to be passed to the constructor, overwrites the default)
            m21 = _m21; // (Vector B z-axis value to be passed to the constructor, overwrites the default)
            m22 = _m22; // (Vector C z-axis value to be passed to the constructor, overwrites the default)
            m23 = _m23; // (Vector D z-axis value to be passed to the constructor, overwrites the default)

            // row 4
            m30 = _m30; // (Vector A w-axis value to be passed to the constructor, overwrites the default)
            m31 = _m31; // (Vector B w-axis value to be passed to the constructor, overwrites the default)
            m32 = _m32; // (Vector C w-axis value to be passed to the constructor, overwrites the default)
            m33 = _m33; // (Vector D w-axis value to be passed to the constructor, overwrites the default)
            */

        }

        public static Vector4 operator *(Matrix4 M, Vector4 V)
        // 5.1.2.0      VECTOR TRANSFORMATION (Matrix by vector multiplication)
        // the resultant vector should be the sum of local x,y,z and w of the Vector multiplied respectively by the x, y and z axes of the matrix.
        {
            return new Vector4(
                // COLUMN MAJOR
                // my comments assume a 1st matrix4 of columns ABCD, and a vector4 of column V
                /*
                (M.m00 * V.x + M.m01 * V.y + M.m02 * V.z + M.m03* V.w),            // Ax * Vx + Bx * Vy + Cx * Vz + Dx * Vw
                (M.m10 * V.x + M.m11 * V.y + M.m12 * V.z + M.m13* V.w),            // Ay * Vx + By * Vy + Cy * Vz + Dy * Vw
                (M.m20 * V.x + M.m21 * V.y + M.m22 * V.z + M.m23* V.w),            // Az * Vx + Bz * Vy + Cz * Vz + Dz * Vw
                (M.m30 * V.x + M.m31 * V.y + M.m32 * V.z + M.m33* V.w));           // Aw * Vx + Bw * Vy + Cw * Vz + Dw * Vw
                */

                // my comments assume a 1st matrix3 of 3 columns ABC, and a vector4 of 1 column V
                // ROW MAJOR
                (M.m00* V.x + M.m10 * V.y + M.m20 * V.z + M.m30 * V.w),      // Ax * Vx + Bx * Vy + Cx * Vz
                (M.m01* V.x + M.m11 * V.y + M.m21 * V.z + M.m31 * V.w),      // Ay * Vx + By * Vy + By * Vz
                (M.m02* V.x + M.m12 * V.y + M.m22 * V.z + M.m32 * V.w),     // Az * Vx + Bz * Vy + Cz * Vz
                (M.m03* V.x + M.m13 * V.y + M.m23 * V.z + M.m33 * V.w));     // Az * Vx + Bz * Vy + Cz * Vz
        }

        public static Matrix4 operator *(Matrix4 M1, Matrix4 M2)
        // 5.1.3.0      MATRIX MULTIPLICATION (Multiply a matrix by a matrix)
        // my comments assume a 1st matrix4 of columns ABCD, and a 2nd matrix4 of columns EFGH
        {
            return new Matrix4(
                // COLUMN MAJOR ORDER
                /*
                // A, B, C & D * ExEyEzEw
                (M1.m00 * M2.m00 + M1.m01 * M2.m10 + M1.m02 * M2.m20 + M1.m03 * M2.m30),  // Ax * Ex + Bx * Ey + Cx * Ez + Dx * Ew
                (M1.m10 * M2.m00 + M1.m11 * M2.m10 + M1.m12 * M2.m20 + M1.m13 * M2.m30),  // Ay * Ex + By * Ey + Cy * Ez + Dy * Ew
                (M1.m20 * M2.m00 + M1.m21 * M2.m10 + M1.m22 * M2.m20 + M1.m23 * M2.m30),  // Az * Ex + Bz * Ey + Cz * Ez + Dz * Ew
                (M1.m30 * M2.m00 + M1.m31 * M2.m10 + M1.m32 * M2.m20 + M1.m33 * M2.m30),  // Aw * Ex + Bw * Ey + Cw * Ez + Dw * Ew

                // A, B, C & D * FxFyFzFw
                (M1.m00 * M2.m01 + M1.m01 * M2.m11 + M1.m02 * M2.m21 + M1.m03 * M2.m31),  // Ax * Fx + Bx * Fy + Cx * Fz + Dx * Fw
                (M1.m10 * M2.m01 + M1.m11 * M2.m11 + M1.m12 * M2.m21 + M1.m13 * M2.m31),  // Ay * Fx + By * Fy + Cy * Fz + Dy * Fw
                (M1.m20 * M2.m01 + M1.m21 * M2.m11 + M1.m22 * M2.m21 + M1.m23 * M2.m31),  // Az * Fx + Bz * Fy + Cz * Fz + Dz * Fw
                (M1.m30 * M2.m01 + M1.m31 * M2.m11 + M1.m32 * M2.m21 + M1.m33 * M2.m31),  // Aw * Fx + Bw * Fy + Cw * Fz + Dw * Fw

                // A, B, C & D * GxGyGzGw
                (M1.m00 * M2.m02 + M1.m01 * M2.m12 + M1.m02 * M2.m22 + M1.m03 * M2.m32),  // Ax * Gx + Bx * Gy + Cx * Gz + Dx * Gw
                (M1.m10 * M2.m02 + M1.m11 * M2.m12 + M1.m12 * M2.m22 + M1.m13 * M2.m32),  // Ay * Gx + By * Gy + Cy * Gz + Dy * Gw
                (M1.m20 * M2.m02 + M1.m21 * M2.m12 + M1.m22 * M2.m22 + M1.m23 * M2.m32),  // Az * Gx + Bz * Gy + Cz * Gz + Dz * Gw
                (M1.m30 * M2.m02 + M1.m31 * M2.m12 + M1.m32 * M2.m22 + M1.m33 * M2.m32),  // Aw * Gx + Bw * Gy + Cw * Gz + Dw * Gw

                // A, B, C & D * HxHyHzHw
                (M1.m00 * M2.m03 + M1.m01 * M2.m13 + M1.m02 * M2.m23 + M1.m03 * M2.m33),  // Ax * Hx + Bx * Hy + Cx * Hz + Dx * Hw
                (M1.m10 * M2.m03 + M1.m11 * M2.m13 + M1.m12 * M2.m23 + M1.m13 * M2.m33),  // Ay * Hx + By * Hy + Cy * Hz + Dy * Hw
                (M1.m20 * M2.m03 + M1.m21 * M2.m13 + M1.m22 * M2.m23 + M1.m23 * M2.m33),  // Az * Hx + Bz * Hy + Cz * Hz + Dz * Hw
                (M1.m30 * M2.m03 + M1.m31 * M2.m13 + M1.m32 * M2.m23 + M1.m33 * M2.m33)); // Aw * Hx + Bw * Hy + Cw * Hz + Dw * Hw
                */

                // ROW MAJOR
                
                (M1.m00 * M2.m00 + M1.m10 * M2.m01 + M1.m20 * M2.m02 + M1.m30 * M2.m03),      // Ax * Ex + Bx * Ey + Cx * Ez + Dx * Ew
                (M1.m01 * M2.m00 + M1.m11 * M2.m01 + M1.m21 * M2.m02 + M1.m31 * M2.m03),      // Ay * Ex + By * Ey + Cy * Ez + Dy * Ew
                (M1.m02 * M2.m00 + M1.m12 * M2.m01 + M1.m22 * M2.m02 + M1.m32 * M2.m03),      // Az * Ex + Bz * Ey + Cz * Ez + Dz * Ew
                (M1.m03 * M2.m00 + M1.m13 * M2.m01 + M1.m23 * M2.m02 + M1.m33 * M2.m03),      // Aw * Ex + Bw * Ey + Cw * Ez + Dw * Ew

                (M1.m00 * M2.m10 + M1.m10 * M2.m11 + M1.m20 * M2.m12 + M1.m30 * M2.m13),      // Ax * Fx + Bx * Fy + Cx * Fz + Dx * Fw
                (M1.m01 * M2.m10 + M1.m11 * M2.m11 + M1.m21 * M2.m12 + M1.m31 * M2.m13),      // Ay * Fx + By * Fy + Cy * Fz + Dy * Fw
                (M1.m02 * M2.m10 + M1.m12 * M2.m11 + M1.m22 * M2.m12 + M1.m32 * M2.m13),      // Az * Fx + Bz * Fy + Cz * Fz + Dz * Fw
                (M1.m03 * M2.m10 + M1.m13 * M2.m11 + M1.m23 * M2.m12 + M1.m33 * M2.m13),      // Aw * Fx + Bw * Fy + Cw * Fz + Dw * Fw
                                                                     
                (M1.m00 * M2.m20 + M1.m10 * M2.m21 + M1.m20 * M2.m22 + M1.m30 * M2.m23),      // Ax * Gx + Bx * Gy + Cx * Gz + Dx * Gw
                (M1.m01 * M2.m20 + M1.m11 * M2.m21 + M1.m21 * M2.m22 + M1.m31 * M2.m23),      // Ay * Gx + By * Gy + Cy * Gz + Dy * Gw
                (M1.m02 * M2.m20 + M1.m12 * M2.m21 + M1.m22 * M2.m22 + M1.m32 * M2.m23),      // Az * Gx + Bz * Gy + Cz * Gz + Dz * Gw
                (M1.m03 * M2.m20 + M1.m13 * M2.m21 + M1.m23 * M2.m22 + M1.m33 * M2.m23),      // Az * Gx + Bz * Gy + Cz * Gz + Dw * Gw

                (M1.m00 * M2.m30 + M1.m10 * M2.m31 + M1.m20 * M2.m32 + M1.m30 * M2.m33),      // Ax * Hx + Bx * Hy + Cx * Hz + Dx * Hw
                (M1.m01 * M2.m30 + M1.m11 * M2.m31 + M1.m21 * M2.m32 + M1.m31 * M2.m33),      // Ay * Hx + By * Hy + Cy * Hz + Dy * Hw
                (M1.m02 * M2.m30 + M1.m12 * M2.m31 + M1.m22 * M2.m32 + M1.m32 * M2.m33),      // Az * Hx + Bz * Hy + Cz * Hz + Dz * Hw
                (M1.m03 * M2.m30 + M1.m13 * M2.m31 + M1.m23 * M2.m32 + M1.m33 * M2.m33));     // Az * Hx + Bz * Hy + Cz * Hz + Dw * Hw
                
        }

        public void SetRotateX(float rotationInRadians)
        // 5.2.0.0      MATRIX TRANSFORM (ROTATION [ONLY X AXIS])     (Multiply a matrix by a rotation matrix)
        {
            // COLUMN MAJOR ORDER
            /*
            this.m00 = 1;   this.m01 = 0;                                   this.m02 = 0;                                   this.m03 = 0;
            this.m10 = 0;   this.m11 = (float)Math.Cos(rotationInRadians);  this.m12 = (float)-Math.Sin(rotationInRadians); this.m13 = 0;
            this.m20 = 0;   this.m21 = (float)Math.Sin(rotationInRadians);  this.m22 = (float)Math.Cos(rotationInRadians);  this.m23 = 0;
            this.m30 = 0;   this.m31 = 0;                                   this.m32 = 0;                                   this.m33 = 1;
            */

            // ROW MAJOR ORDER
            
            this.m00 = 1; this.m01 = 0;                                     this.m02 = 0;                                   this.m03 = 0;
            this.m10 = 0; this.m11 = (float)Math.Cos(rotationInRadians);    this.m12 = (float)Math.Sin(rotationInRadians);  this.m13 = 0;
            this.m20 = 0; this.m21 = (float)-Math.Sin(rotationInRadians);   this.m22 = (float)Math.Cos(rotationInRadians);  this.m23 = 0;
            this.m30 = 0; this.m31 = 0;                                     this.m32 = 0;                                   this.m33 = 1;
            
        }

        public void SetRotateY(float rotationInRadians)
        // 5.3.0.0      MATRIX TRANSFORM (ROTATION [ONLY Y AXIS])     (Multiply a matrix by a rotation matrix)
        {
            // COLUMN MAJOR ORDER
            
            this.m00 = (float)Math.Cos(rotationInRadians); this.m01 = 0;  this.m02 = (float)-Math.Sin(rotationInRadians);    this.m03 = 0;
            this.m10 = 0;                                  this.m11 = 1;  this.m12 = 0;                                      this.m13 = 0;
            this.m20 = (float)Math.Sin(rotationInRadians); this.m21 = 0;  this.m22 = (float)Math.Cos(rotationInRadians);     this.m23 = 0;
            this.m30 = 0;                                  this.m31 = 0;  this.m32 = 0;                                      this.m33 = 1;
            

            // ROW MAJOR ORDER
            /*
            this.m00 = (float)Math.Cos(rotationInRadians);  this.m01 = 0;  this.m02 = (float)Math.Sin(rotationInRadians);     this.m03 = 0;
            this.m10 = 0;                                   this.m11 = 1;  this.m12 = 0;                                      this.m13 = 0;
            this.m20 = (float)-Math.Sin(rotationInRadians); this.m21 = 0;  this.m22 = (float)Math.Cos(rotationInRadians);     this.m23 = 0;
            this.m30 = 0;                                   this.m31 = 0;  this.m32 = 0;                                      this.m33 = 1;
            */
        }

        public void SetRotateZ(float rotationInRadians)
        // 5.4.0.0      MATRIX TRANSFORM (ROTATION [ONLY Z AXIS])     (Multiply a matrix by a rotation matrix)
        {
            // COLUMN MAJOR ORDER
            /*
            this.m00 = (float)Math.Cos(rotationInRadians); this.m01 = (float)-Math.Sin(rotationInRadians);    this.m02 = 0;  this.m03 = 0;
            this.m10 = (float)Math.Sin(rotationInRadians); this.m11 = (float)Math.Cos(rotationInRadians);     this.m12 = 0;  this.m13 = 0;
            this.m20 = 0;                                  this.m21 = 0;                                      this.m22 = 1;  this.m23 = 0;
            this.m30 = 0;                                  this.m31 = 0;                                      this.m32 = 0;  this.m33 = 1;
            */

            // ROW MAJOR ORDER
            
            this.m00 = (float)Math.Cos(rotationInRadians);  this.m01 = (float)Math.Sin(rotationInRadians);      this.m02 = 0;  this.m03 = 0;
            this.m10 = (float)-Math.Sin(rotationInRadians); this.m11 = (float)Math.Cos(rotationInRadians);      this.m12 = 0;  this.m13 = 0;
            this.m20 = 0;                                   this.m21 = 0;                                       this.m22 = 1;  this.m23 = 0;
            this.m30 = 0;                                   this.m31 = 0;                                       this.m32 = 0;  this.m33 = 1;
            
        }
    }
}