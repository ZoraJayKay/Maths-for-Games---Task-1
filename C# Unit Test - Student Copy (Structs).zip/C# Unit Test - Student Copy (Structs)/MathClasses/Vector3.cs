﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MathClasses
{
    /* Write Vector data types for 3D vectors, including homogeneous 3D vectors. Types implement methods for, in all instances:
     * 1: translation
     * 2: scale
     * 3: magnitude
     * 4: normalisation
     * 5: cross product 
     * 6: dot product. 
    */

    public struct Vector3
    // 2.1.0.0      struct
    {
        public float x, y, z;   // 2.1.0.1; 2.1.0.2; 2.1.0.3    automatically-initialised default variables

        public Vector3(float _x, float _y, float _z)
        // 2.1.1.0      overloaded constructor (replace default xyz with passed-in xyz)
        // vvv      this set of variables is only used where a vector calls a method on itself rather than passing it all parameters
        //          eg: "V1.Dot(V2)"    ... rather than...  "Dot(V1, V2)"
        {
            this.x = _x;    // 2.1.1.1      x-axis value to overwrite the struct default
            this.y = _y;    // 2.1.1.2      y-axis value to overwrite the struct default
            this.z = _z;    // 2.1.1.3      z-axis value to overwrite the struct default
        }

        // 2.1.2.0      TRANSFORM: ADDITION       overloaded operator (add two vector3's together)
        public static Vector3 operator +(Vector3 lhs, Vector3 rhs)
        {
            return new Vector3(
                lhs.x + rhs.x,
                lhs.y + rhs.y,
                lhs.z + rhs.z);
        }

        // 2.1.3.0      TRANSFORM: SUBTRACTION    overloaded operator (deduct one vector3 from another)
        public static Vector3 operator -(Vector3 lhs, Vector3 rhs)
        {
            return new Vector3(
                lhs.x - rhs.x,
                lhs.y - rhs.y,
                lhs.z - rhs.z);
        }

        // 2.1.4.0      TRANSFORM: SCALE (Float - multiply)    overloaded operator (accept one Vector3 and multiply it by a float)
        public static Vector3 operator *(Vector3 lhs, float rhs)
        {
            return new Vector3(lhs.x * rhs, lhs.y * rhs, lhs.z * rhs);
        }

        // 2.1.5.0      TRANSFORM: SCALE (Float - multiply)    overloaded operator (accept one float and multiply it by a Vector3)
        public static Vector3 operator *(float rhs, Vector3 lhs)
        {
            return new Vector3(lhs.x, lhs.y, lhs.z) * rhs;
        }

        // 2.1.6.0      TRANSFORM: SCALE (Float - divide)      overloaded operator (accept one float and divide it by a Vector3)
        public static Vector3 operator /(Vector3 lhs, float rhs)
        {
            return new Vector3(lhs.x / rhs, lhs.y / rhs, lhs.z / rhs);
        }

        // 2.1.7.0      TRANSFORM: SCALE (Float - divide)      overloaded operator (accept one float and divide it by a Vector3)
        public static Vector3 operator /(float rhs, Vector3 lhs)
        {
            return new Vector3(lhs.x, lhs.y, lhs.z) / rhs;
        }

        // 2.2.0.0      DOT PRODUCT                             Method set up to accept one Vector3, presumption is that method is called from a Vector3 itself (so only needs to pass in one)
        // dot product returns a scalar value which is the length of the two vectors multiplied by the cosine of the angle between them
        public float Dot(Vector3 V1)
        {
            float dotProduct = (V1.x * this.x) + (V1.y * this.y) + (V1.z * this.z);
            return dotProduct;
        }

        // 2.3.0.0      CROSS PRODUCT                             Method set up to accept one Vector3, presumption is that method is called from a Vector3 itself (so only needs to pass in one)
        // cross product returns a vector perpendicular to the two input vectors
        public Vector3 Cross(Vector3 V1)
        {
            return new Vector3(
                y * V1.z - z * V1.y,  // x axis result (I don't seem to need to use "this." here)
                z * V1.x - x * V1.z,  // y axis result
                x * V1.y - y * V1.x); // z axis result
        }

        // 2.4.0.0      MAGNITUDE
        // return the magnitude of the vector that calls this function
        public float Magnitude()
        {
            float magnitude = (float)Math.Sqrt((this.x * this.x) + (this.y * this.y) + (this.z * this.z));            
            return magnitude;            
        }

        // 2.5.0.0      NORMALIZE
        // make the magnitude of a vector equal to 1 / make the vector a unit vector
        public void Normalize()
        {
            float magnitude = this.Magnitude();
            this.x = this.x / magnitude;
            this.y = this.y / magnitude;
            this.z = this.z / magnitude;
        }
    }
}
