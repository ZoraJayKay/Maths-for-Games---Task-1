﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MathClasses
{
    /* Write Matrix data types for 3D matrices, including homogeneous 4D matrices. Types implement methods for:
     * 1: multiplication
     * 2: vector transformation
     * 3: transpose
     * 4: setting up as rotation matrices
    */

    // IN ORDER TO WORK WITH THE UNIT TEST I HAD TO USE ROW MAJOR ORDER


    public struct Matrix3
    // 4.1.0.0      struct
    {
        // 4.1.0.1 - 4.1.0.9
        public float m00, m01, m02; // Ax, Bx, Cx       these could also be public Vector3, rather than a float, if desired
        public float m10, m11, m12; // Ay, By, Cy       declaring floats avoids using a separate memory allocation, which happens with an array.
        public float m20, m21, m22; // Az, Bz, Cz       these are automatically-initialised default variables

        
        // 4.1.1.0      overloaded constructor ROW MAJOR ORDER (replace default xyz with passed-in xyz)
        public Matrix3(float _m00, float _m01, float _m02, float _m10, float _m11, float _m12, float _m20, float _m21, float _m22)
        {
            // 4.1.1.1 - 4.1.1.9
            // Column 1
            m00 = _m00; // (Vector A x-axis value to be passed to the constructor, overwrites the default)
            m10 = _m10; // (Vector A y-axis value to be passed to the constructor, overwrites the default)
            m20 = _m20; // (Vector A z-axis value to be passed to the constructor, overwrites the default)

            // Column 2
            m01 = _m01; // (Vector B x-axis value to be passed to the constructor, overwrites the default)
            m11 = _m11; // (Vector B y-axis value to be passed to the constructor, overwrites the default)
            m21 = _m21; // (Vector B z-axis value to be passed to the constructor, overwrites the default)

            // Column 3
            m02 = _m02; // (Vector C x-axis value to be passed to the constructor, overwrites the default)
            m12 = _m12; // (Vector C y-axis value to be passed to the constructor, overwrites the default)
            m22 = _m22; // (Vector C z-axis value to be passed to the constructor, overwrites the default)
        }

        //public Matrix3(float _m00, float _m10, float _m20, float _m01, float _m11, float _m21, float _m02, float _m12, float _m22)
        //// 4.1.1.0      overloaded constructor COLUMN MAJOR ORDER (replace default xyz with passed-in xyz)         
        //{
        //    //4.1.1.1 - 4.1.1.9
        //    //Column 1
        //    m00 = _m00; // (Vector A x-axis value to be passed to the constructor, overwrites the default)
        //    m10 = _m10; // (Vector A y-axis value to be passed to the constructor, overwrites the default)
        //    m20 = _m20; // (Vector A z-axis value to be passed to the constructor, overwrites the default)

        //    // Column 2
        //    m01 = _m01; // (Vector B x-axis value to be passed to the constructor, overwrites the default)
        //    m11 = _m11; // (Vector B y-axis value to be passed to the constructor, overwrites the default)
        //    m21 = _m21; // (Vector B z-axis value to be passed to the constructor, overwrites the default)

        //    // Column 3
        //    m02 = _m02; // (Vector C x-axis value to be passed to the constructor, overwrites the default)
        //    m12 = _m12; // (Vector C y-axis value to be passed to the constructor, overwrites the default)
        //    m22 = _m22; // (Vector C z-axis value to be passed to the constructor, overwrites the default)
        //}


        // identity matrix
        // 4.1.1.10      overloaded constructor ROW MAJOR ORDER (replace default xyz with passed-in float)
        public Matrix3(float size)  // 4.1.1.11
        {
            // row 1
            m00 = 1 * size; // (Vector A x-axis value to be passed to the constructor, overwrites the default)
            m10 = 0;        // (Vector B x-axis value to be passed to the constructor, overwrites the default)
            m20 = 0;        // (Vector C x-axis value to be passed to the constructor, overwrites the default)

            // row 2
            m01 = 0;        // (Vector A y-axis value to be passed to the constructor, overwrites the default)
            m11 = 1 * size; // (Vector B y-axis value to be passed to the constructor, overwrites the default)
            m21 = 0;        // (Vector C y-axis value to be passed to the constructor, overwrites the default)

            // row 3
            m02 = 0;        // (Vector A z-axis value to be passed to the constructor, overwrites the default)
            m12 = 0;        // (Vector B z-axis value to be passed to the constructor, overwrites the default)
            m22 = 1 * size; // (Vector C z-axis value to be passed to the constructor, overwrites the default)
        }


        public static Vector3 operator *(Matrix3 M, Vector3 V)
        // 4.1.2.0      VECTOR TRANSFORMATION: SCALE (MULTIPLICATION)   (Matrix by vector multiplication; 3x3 matrix * 3x1 vector = 3x1 vector)
        // the resultant vector should be the sum of local x,y and z of the Vector multiplied respectively by the x, y and z axes of the matrix.
        // Result vector = Input Vector.x * Matrix X-Axis + Input Vector.y * Matrix Y-Axis= Input Vector.z * Matrix Z-Axis
        {
            return new Vector3(
                // my comments assume a 1st matrix3 of 3 columns ABC, and a vector3 of 1 column V
                // ROW MAJOR
                M.m00 * V.x + M.m10 * V.y + M.m20 * V.z,      // Ax * Vx + Bx * Vy + Cx * Vz
                M.m01 * V.x + M.m11 * V.y + M.m21 * V.z,      // Ay * Vx + By * Vy + By * Vz
                M.m02 * V.x + M.m12 * V.y + M.m22 * V.z);     // Az * Vx + Bz * Vy + Cz * Vz

            // COLUMN MAJOR
            /*
                M.m00 * V.x + M.m01 * V.y + M.m02 * V.z,      // Ax * Vx + Bx * Vy + Cx * Vz
                M.m10 * V.x + M.m11 * V.y + M.m12 * V.z,      // Ay * Vx + By * Vy + By * Vz
                M.m20 * V.x + M.m21 * V.y + M.m22 * V.z);     // Az * Vx + Bz * Vy + Cz * Vz
            */
        }

        public static Matrix3 operator *(Matrix3 M1, Matrix3 M2)
        // 4.1.3.0      MATRIX MULTIPLICATION                           (Multiply a matrix by a matrix; 3x3 matrix * 3x3 matrix = 3x3 matrix)
        // my comments assume a 1st matrix3 of 3 columns ABC, and a 2nd matrix of 3 columns DEF
        {
            return new Matrix3(
                // COLUMN MAJOR
                // Axyz, Bxyz and Cxyz * DxDyDz
                // (M1.m00 * M2.m00 + M1.m01 * M2.m10 + M1.m02 * M2.m20),  // Ax * Dx + Bx * Dy + Cx * Dz
                // (M1.m10 * M2.m00 + M1.m11 * M2.m10 + M1.m12 * M2.m20),  // Ay * Dx + By * Dy + Cy * Dz
                // (M1.m20 * M2.m00 + M1.m21 * M2.m10 + M1.m22 * M2.m20),  // Az * Dx + Bz * Dy + Cz * Dz

                // A, B and C * ExEyEz
                // (M1.m00 * M2.m01 + M1.m01 * M2.m11 + M1.m02 * M2.m21),  // Ax * Ex + Bx * Ey + Cx * Ez
                // (M1.m10 * M2.m01 + M1.m11 * M2.m11 + M1.m12 * M2.m21),  // Ay * Ex + By * Ey + Cy * Ez
                // (M1.m20 * M2.m01 + M1.m21 * M2.m11 + M1.m22 * M2.m21),  // Az * Ex + Bz * Ey + Cz * Ez

                // A, B and C * FxFyFz
                // (M1.m00 * M2.m02 + M1.m01 * M2.m12 + M1.m02 * M2.m22),  // Ax * Fx + Bx * Fy + Cx * Fz
                // (M1.m10 * M2.m02 + M1.m11 * M2.m12 + M1.m12 * M2.m22),  // Ay * Fx + By * Fy + Cy * Fz
                // (M1.m20 * M2.m02 + M1.m21 * M2.m12 + M1.m22 * M2.m22)); // Az * Fx + Bz * Fy + Cz * Fz

                // ROW MAJOR
                (M1.m00 * M2.m00 + M1.m10 * M2.m01 + M1.m20 * M2.m02),      // Ax * Dx + Bx * Dy + Cx * Dz
                (M1.m01 * M2.m00 + M1.m11 * M2.m01 + M1.m21 * M2.m02),      // Ay * Dx + By * Dy + Cy * Dz
                (M1.m02 * M2.m00 + M1.m12 * M2.m01 + M1.m22 * M2.m02),      // Az * Dx + Bz * Dy + Cz * Dz

                (M1.m00 * M2.m10 + M1.m10 * M2.m11 + M1.m20 * M2.m12),      // Ax * Ex + Bx * Ey + Cx * Ez
                (M1.m01 * M2.m10 + M1.m11 * M2.m11 + M1.m21 * M2.m12),      // Ay * Ex + By * Ey + Cy * Ez
                (M1.m02 * M2.m10 + M1.m12 * M2.m11 + M1.m22 * M2.m12),      // Az * Ex + Bz * Ey + Cz * Ez

                (M1.m00 * M2.m20 + M1.m10 * M2.m21 + M1.m20 * M2.m22),      // Ax * Fx + Bx * Fy + Cx * Fz
                (M1.m01 * M2.m20 + M1.m11 * M2.m21 + M1.m21 * M2.m22),      // Ay * Fx + By * Fy + Cy * Fz
                (M1.m02 * M2.m20 + M1.m12 * M2.m21 + M1.m22 * M2.m22));     // Az * Fx + Bz * Fy + Cz * Fz
        }
                
        public void SetRotateX(float rotationInRadians)
        // 4.2.0.0      MATRIX TRANSFORM (ROTATION [ONLY X AXIS])     (Multiply a matrix by a rotation matrix)
        {   
            // COLUMN MAJOR ORDER
            // this.m00 = 1;  this.m01 = 0;                                  this.m02 = 0;
            // this.m10 = 0;  this.m11 = (float)Math.Cos(rotationInRadians); this.m12 = (float)-Math.Sin(rotationInRadians);
            // this.m20 = 0;  this.m21 = (float)Math.Sin(rotationInRadians); this.m22 = (float)Math.Cos(rotationInRadians);

            // ROW MAJOR ORDER
            this.m00 = 1;  this.m01 = 0;                                  this.m02 = 0;
            this.m10 = 0;  this.m11 = (float)Math.Cos(rotationInRadians); this.m12 = (float)Math.Sin(rotationInRadians);
            this.m20 = 0;  this.m21 = (float)-Math.Sin(rotationInRadians); this.m22 = (float)Math.Cos(rotationInRadians);

        }

        public void SetRotateY(float rotationInRadians)
        // 4.3.0.0      MATRIX TRANSFORM (ROTATION [ONLY Y AXIS])     (Multiply a matrix by a rotation matrix)
        {
            // COLUMN MAJOR ORDER
            this.m00 = (float)Math.Cos(rotationInRadians); this.m01 = 0; this.m02 = (float)-Math.Sin(rotationInRadians);
            this.m10 = 0;                                  this.m11 = 1; this.m12 = 0;
            this.m20 = (float)Math.Sin(rotationInRadians); this.m21 = 0; this.m22 = (float)Math.Cos(rotationInRadians);

            // ROW MAJOR ORDER
            // m00 = (float)Math.Cos(rotationInRadians);  this.m01 = 0; this.m02 = (float)Math.Sin(rotationInRadians);
            // m10 = 0;                                   this.m11 = 1; this.m12 = 0;
            // m20 = (float)-Math.Sin(rotationInRadians); this.m21 = 0; this.m22 = (float)Math.Cos(rotationInRadians);
        }

        public void SetRotateZ(float rotationInRadians)
        // 4.4.0.0      MATRIX TRANSFORM (ROTATION [ONLY Z AXIS])     (Multiply a matrix by a rotation matrix)
        {
            // COLUMN MAJOR ORDER
            // this.m00 = (float)Math.Cos(rotationInRadians); this.m01 = (float)-Math.Sin(rotationInRadians);    this.m02 = 0;
            // this.m10 = (float)Math.Sin(rotationInRadians); this.m11 = (float)Math.Cos(rotationInRadians);     this.m12 = 0;
            // this.m20 = 0;                                  this.m21 = 0;                                      this.m22 = 1;

            // ROW MAJOR ORDER
            this.m00 = (float)Math.Cos(rotationInRadians);     this.m01 = (float)Math.Sin(rotationInRadians); this.m02 = 0;
            this.m10 = (float)-Math.Sin(rotationInRadians);    this.m11 = (float)Math.Cos(rotationInRadians); this.m12 = 0;
            this.m20 = 0;                                      this.m21 = 0;                                  this.m22 = 1;
        }

        public void TransposeMatrix(Matrix3 M)
        // 4.5.0.0      MATRIX TRANSPOSITION (Swap matrix rows and columns)
        {
            Matrix3 tMatrix = new Matrix3(
                M.m00, M.m10, M.m20,
                M.m01, M.m11, M.m21,
                M.m02, M.m12, M.m22);

            Console.WriteLine("" +
                $"The matrix     [{M.m00}][{M.m01}][{M.m02}]\n" +
                $"               [{M.m10}][{M.m11}][{M.m12}]\n" +
                $"               [{M.m20}][{M.m21}][{M.m22}]   transposed is:\n\n" +
                "" +
                $"               [{tMatrix.m00}][{tMatrix.m01}][{tMatrix.m02}]\n" +
                $"               [{tMatrix.m10}][{tMatrix.m11}][{tMatrix.m12}]\n" +
                $"               [{tMatrix.m20}][{tMatrix.m21}][{tMatrix.m22}]");
        }
        public void SetScaleX(float scaleX)
        // 4.6.0.0      MATRIX TRANSFORM (SCALE [ONLY X AXIS])     (Multiply a matrix by a scale matrix)
        {
            this.m00 = scaleX; this.m01 = 0; this.m02 = 0;
            this.m10 = 0;      this.m11 = 1; this.m12 = 0;
            this.m20 = 0;      this.m21 = 0; this.m22 = 1;
        }

        public void SetScaleY(float scaleY)
        // 4.7.0.0      MATRIX TRANSFORM (SCALE [ONLY Y AXIS])     (Multiply a matrix by a scale matrix)
        {
            this.m00 = 1; this.m01 = 0;       this.m02 = 0;
            this.m10 = 0; this.m11 = scaleY;  this.m12 = 0;
            this.m20 = 0; this.m21 = 0;       this.m22 = 1;
        }

        public void SetScaleZ(float scaleZ)
        // 4.8.0.0      MATRIX TRANSFORM (SCALE [ONLY Z AXIS])     (Multiply a matrix by a scale matrix)
        {
            this.m00 = 1; this.m01 = 0; this.m02 = 0;
            this.m10 = 0; this.m11 = 1; this.m12 = 0;
            this.m20 = 0; this.m21 = 0; this.m22 = scaleZ;
        }

        public void SetScaleAll(float scaleX, float scaleY, float scaleZ)
        // 4.9.0.0      MATRIX TRANSFORM (SCALE [ALL AXES])     (Multiply a matrix by a scale matrix)
        // I haven't actually created the functionality for this in the unit test, but it would request 3 floats from the user in turn (x, y and z) which would then be multiplied over the matrix which called this method
        {
            this.m00 = scaleX; this.m01 = 0;      this.m02 = 0;
            this.m10 = 0;      this.m11 = scaleY; this.m12 = 0;
            this.m20 = 0;      this.m21 = 0;      this.m22 = scaleZ;
        }


        // *** NOTE TO SELF: THERE IS A DISTINCTION BETWEEN SETTRANSLATE AND TRANSLATE ***
        // ** SETTRANSLATE AKA MOVING TO ABSOLUTE DESTINATION; TELEPORTING**
        // * TRANSLATE AKA MOVING RELATIVE POSITION; WALKING*

        public void SetTranslation(float x, float y)
        // 4.10.0.0      MATRIX TRANSLATION (TELEPORT)
        {
            //// COLUMN MAJOR ORDER
            // this.m02 = x; this.m12 = y;

            // ROW MAJOR ORDER
            this.m20 = x; this.m21 = y;
        }

        public void Translate(float x, float y)
        // 4.11.0.0      MATRIX TRANSLATION (MOVE RELATIVE)
        {
            //// COLUMN MAJOR ORDER
            // this.m02 += x; this.m12 += y;

            // ROW MAJOR ORDER
            this.m20 += x; this.m21 += y;
        }



        //public void RotateX(float rotationInRadians)
        //// MATRIX TRANSFORM (ROTATION [ONLY X AXIS])     (Multiply a matrix by a rotation matrix)
        //{
        //// COLUMN MAJOR ORDER
        // this.m00 *= 1;  this.m01 *= 0;                                  this.m02 *= 0;
        // this.m10 *= 0;  this.m11 *= (float)Math.Cos(rotationInRadians); this.m12 *= (float)-Math.Sin(rotationInRadians);
        // this.m20 *= 0;  this.m21 *= (float)Math.Sin(rotationInRadians); this.m22 *= (float)Math.Cos(rotationInRadians);

        //// ROW MAJOR ORDER
        //    this.m00 *= 1; this.m01 *= 0; this.m02 *= 0;
        //    this.m10 *= 0; this.m11 *= (float)Math.Cos(rotationInRadians); this.m12 *= (float)Math.Sin(rotationInRadians);
        //    this.m20 *= 0; this.m21 *= (float)-Math.Sin(rotationInRadians); this.m22 *= (float)Math.Cos(rotationInRadians);
        //}

        //public void RotateY(float rotationInRadians)
        //// MATRIX TRANSFORM (ROTATION [ONLY Y AXIS])     (Multiply a matrix by a rotation matrix)
        //{
        //// COLUMN MAJOR ORDER
        //this.m00 *= (float)Math.Cos(rotationInRadians); this.m01 *= 0; this.m02 *= (float)-Math.Sin(rotationInRadians);
        //this.m10 *= 0; this.m11 *= 1; this.m12 *= 0;
        //this.m20 *= (float)Math.Sin(rotationInRadians); this.m21 *= 0; this.m22 *= (float)Math.Cos(rotationInRadians);

        //// ROW MAJOR ORDER
        // m00 *= (float)Math.Cos(rotationInRadians);  this.m01 *= 0; this.m02 *= (float)Math.Sin(rotationInRadians);
        // m10 *= 0;                                   this.m11 *= 1; this.m12 *= 0;
        // m20 *= (float)-Math.Sin(rotationInRadians); this.m21 *= 0; this.m22 *= (float)Math.Cos(rotationInRadians);
        //}

        //public void RotateZ(float rotationInRadians)
        //// MATRIX TRANSFORM (ROTATION [ONLY Z AXIS])     (Multiply a matrix by a rotation matrix)
        //{
        //// COLUMN MAJOR ORDER
        // this.m00 *= (float)Math.Cos(rotationInRadians); this.m01 *= (float)-Math.Sin(rotationInRadians);    this.m02 *= 0;
        // this.m10 *= (float)Math.Sin(rotationInRadians); this.m11 *= (float)Math.Cos(rotationInRadians);     this.m12 *= 0;
        // this.m20 *= 0;                                  this.m21 *= 0;                                      this.m22 *= 1;

        //// ROW MAJOR ORDER
        //this.m00 *= (float)Math.Cos(rotationInRadians); this.m01 *= (float)Math.Sin(rotationInRadians); this.m02 *= 0;
        //this.m10 *= (float)-Math.Sin(rotationInRadians); this.m11 *= (float)Math.Cos(rotationInRadians); this.m12 *= 0;
        //this.m20 *= 0; this.m21 *= 0; this.m22 *= 1;
        //}
    }
}