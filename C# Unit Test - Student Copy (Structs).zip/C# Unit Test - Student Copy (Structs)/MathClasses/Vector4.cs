﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathClasses
{
    /* Write Vector data types for 3D vectors, including homogeneous 3D vectors. Types implement methods for, in all instances:
     * 1: translation
     * 2: scale
     * 3: magnitude
     * 4: normalisation
     * 5: cross product 
     * 6: dot product. 
    */

    public struct Vector4
    // 3.1.0.0      struct
    {
        public float x; // 3.1.0.1
        public float y; // 3.1.0.2
        public float z; // 3.1.0.3
        public float w; // 3.1.0.4
        // the members of a struct are automatically initialised to the default values for their data type, so these                            will be 0.

        
        public Vector4(float _x, float _y, float _z, float _w)
        // 3.1.1.0      overloaded constructor (replace default xyz with passed-in xyz)
        // vvv      this set of variables is only used where a vector calls a method on itself rather than passing it all parameters
        //          eg: "V1.Dot(V2)"    ... rather than...  "Dot(V1, V2)"
        {
            this.x = _x;
            this.y = _y;
            this.z = _z;
            this.w = _w;
        }


        // 3.1.2.0      TRANSFORM: ADDITION       overloaded operator (add two vector4's together)
        public static Vector4 operator +(Vector4 lhs, Vector4 rhs)
        {
            return new Vector4(
                lhs.x + rhs.x,
                lhs.y + rhs.y,
                lhs.z + rhs.z,
                lhs.w + rhs.w);
        }

        // 3.1.3.0      TRANSFORM: SUBTRACTION    overloaded operator (deduct one vector4 from another)
        public static Vector4 operator -(Vector4 lhs, Vector4 rhs)
        {
            return new Vector4(
                lhs.x - rhs.x,
                lhs.y - rhs.y,
                lhs.z - rhs.z,
                lhs.w - rhs.w);
        }

        // 3.1.4.0      TRANSFORM: SCALE (Float - multiply)    overloaded operator (accept one Vector4 and multiply it by a float)
        public static Vector4 operator *(Vector4 lhs, float rhs)
        {
            return new Vector4(lhs.x * rhs, lhs.y * rhs, lhs.z * rhs, lhs.w * rhs);   // w axis set to 0 by convention
        }

        // 3.1.5.0      TRANSFORM: SCALE (Float - multiply)    overloaded operator (accept one float and multiply it by a Vector4)
        public static Vector4 operator *(float rhs, Vector4 lhs)
        {
            return new Vector4(lhs.x * rhs, lhs.y * rhs, lhs.z * rhs, lhs.w * rhs);   // w axis set to 0 by convention
        }

        // 3.1.6.0      TRANSFORM: SCALE (Float - divide)      overloaded operator (accept one float and divide it by a Vector4)
        public static Vector4 operator /(Vector4 lhs, float rhs)
        {
            return new Vector4(lhs.x, lhs.y, lhs.z, lhs.w) / rhs;
        }

        // 3.1.7.0      TRANSFORM: SCALE (Float - divide)      overloaded operator (accept one float and divide it by a Vector4)
        public static Vector4 operator /(float rhs, Vector4 lhs)
        {
            return new Vector4(lhs.x, lhs.y, lhs.z, lhs.w) / rhs;
        }

        // 3.2.0.0      DOT PRODUCT                             Method set up to accept one Vector4, presumption is that method is called from a Vector4 itself (so only needs to pass in one)
        // dot product returns a scalar value which is the length of the two vectors multiplied by the cosine of the angle between them
        // for Vector4 the w will conventionally be 0
        public float Dot(Vector4 V1)
        {
            float dotProduct =
                    (V1.x * this.x) + 
                    (V1.y * this.y) + 
                    (V1.z * this.z) + 
                    (V1.w * this.w);
            return dotProduct;
        }

        // 3.3.0.0      CROSS PRODUCT                             Method set up to accept one Vector4, presumption is that method is called from a Vector4 itself (so only needs to pass in one)
        // cross product returns a vector perpendicular to the two input vectors
        // for Vector4 the w will conventionally be 0
        public Vector4 Cross(Vector4 V1)
        {
            return new Vector4(
                this.y * V1.z - this.z * V1.y,  // x axis result
                this.z * V1.x - this.x * V1.z,  // y axis result
                this.x * V1.y - this.y * V1.x,  // z axis result
                0);                             // w axis is 0 by convention
        }

        // 3.4.0.0      MAGNITUDE
        // return the magnitude of the vector that calls this function
        public float Magnitude()
        {
            float magnitude = (float)Math.Sqrt((this.x * this.x) + (this.y * this.y) + (this.z * this.z) + (this.w * this.w));
            return magnitude;
        }

        // 3.5.0.0      NORMALIZE
        // make the magnitude of a vector equal to 1 / make the vector a unit vector
        public void Normalize()
        {
            float magnitude = this.Magnitude();
            this.x = this.x / magnitude;
            this.y = this.y / magnitude;
            this.z = this.z / magnitude;
            this.w = this.w / magnitude;
        }
    }
}
