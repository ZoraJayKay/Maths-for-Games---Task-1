﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* reminder:
         * 
         * BITWISE OPERATORS
         * '&'  bitwise AND
         *          yields a value if both bits are set, otherwise 0 
         * '|'  bitwise OR
         *          yields a value if either bits are set
         * '~'  bitwise NOT
         *          flips each bit, 1 becomes 0 and vice versa
         * '^'  bitwise XOR
         *          yields a value of 1 if bits are different, 0 if same
         *          
         * BITSHIFTING
         *      Bitshifted digits that are shifted off the end do not wrap around - they are lost!
         * '<<' left shift
         *          
         * '>>' right shift
         * 
         */

namespace MathClasses
{
    public struct Colour
    {
        

        public UInt32 colour;
        // Four byte integer representing Red; Green; Blue; Alpha, in the most to least significant bytes


        public Colour(byte r, byte g, byte b, byte a)
        {
            red = r;
            green = g;
            blue = b;
            alpha = a;
        }


        public byte red
        /* most significant value, bitshift by 3 bytes to get and set (8 bits * 3 bytes = 24 bits)
         * 
         * The 0x prefix means that we are working in hexadecimal.
         * 
         * 
         * 
         */


        {
            get
            {
                return (byte)((colour >> 24) & 0b11111111);
            }
            
            // get a colour variable (type unsigned integer 32) and return it after explicitly converting it to type byte, and bitshifting right by 24 bits. Apply a bitmask so we are only getting the final 8 bits (for the 1 red byte only).

            // get a colour as an integer and bitshift it 24 bits.
            // 

            /* To represent a byte, we work in pairs of characters for hexadecimal because 2 digits is equal to 8 digits in binary.
             * 
             * We will be setting 1 byte, red, to somewhere between minimum (0, or [0000 0000]) and maximum redness (255, or [1111 1111]).
             * 
             * 'f' is hexadecimal code for the highest value in the first digit of base 16 (0-9 then A-F), which is equal to the number 15 as an integer (0-15), or the binary state (0000 1111) in a byte (because to reach f, or 15, first 4 digits must be 'on' or 1's).
             * 
             * 'ff' is hexadecimal code for the highest value in the first TWO digits of base 16, which is equal to the number 255 as an integer (0-256), or the binary state (1111 1111) in a byte (because to reach ff, or 255, all 8 digits must be 'on' or 1's).
             * 
             * 'ff' therefore translates in binary to "turn on all of the bits in this byte" or "set this byte to its maximum colour"
             * 
             * 0x prefix sets as hexadecimal
            */


            set { colour = (colour & 0x00ffffff) | ((UInt32)value << 24); }         // 00ffffff to ffffff00
            // make a combination of the red value plus the existing value with the red bits cleared.

            // 00  ff  ff  ff
            // 00  255 255 255
        }

        public byte green
        {
            get { return (byte)((colour >> 16) & 0b11111111); }
            //set { colour = (colour & 0xff00ffff) | ((UInt32)value << 16); }
            set { colour = (colour & 0b11111111000000001111111111111111) | ((UInt32)value << 16); }
        }

        public byte blue
        {
            get { return (byte)((colour >> 8) & 0b11111111); }
            //set { colour = (colour & 0xffff00ff) | ((UInt32)value << 8); }
            set { colour = (colour & 0b11111111111111110000000011111111) | ((UInt32)value << 8); }
        }

        public byte alpha
        {
            get { return (byte)((colour) & 0b11111111); }
            //set { colour = (colour & 0xffffff00) | ((UInt32)value); }
            set { colour = (colour & 0b11111111111111111111111100000000) | ((UInt32)value); }
        }        
    }
}
